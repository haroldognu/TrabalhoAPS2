<!DOCTYPE html>
<html>
<head>
	<title>Login </title>
	<link rel="stylesheet" type="text/css" href="/_css/style.css">
</head>
<body>
<div id="baner"> <img src="_image/2.png"></div>

<div id="copo"> 

	<form>
		<h1>Login</h1>
		<label>Nome</label>
		<input type="text" name="nome"><br>
		<label>Senha</label>
		<input type="password" name="senha"><br>
		<br>
		<button>ENTRA</button> <button> <a href="cadastro-usuario.php">Cadastrar</button></a>



	</form>

  </div>
<hr>

<div id="rodape">Desenvolvido:Grupo(Haroldo,Miqueias,Angelo,Kelly)</div>

<hr>

</body>
</html>