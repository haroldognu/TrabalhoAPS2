<!DOCTYPE html>
<html>
<head>
	<title>Cadastro Usuario </title>
	<link rel="stylesheet" type="text/css" href="/_css/style.css">
</head>
<body>
<div id="baner"> <img src="_image/2.png"></div>

<div id="copo"> 
	
	 <form method="POST" action="cadastro.php">
Cadastro:
                        <br>
                        <br>
                        <label>Nome:
                            
                        <textarea name="Nome:" id="NomeTex" cols="10" rows="01"></textarea>
                    </label>

                    <br>
                    <label>Senha:
                        
                    <textarea name="Senha:" id="SenhaTex" cols="10" rows="01"></textarea>
                </label>
                <br>
                <label>Data Nascimento:
                  
                <input type="date" onkeypress="formatar">
            </label>

            <br>
            <label>Pais:
                
                    <select>
                            <option>Brasil</option>
                            <option>ES</option>
                            <option>ES</option>
        
                            <option>ES</option>
        
        
                    </select>
        </label>

        <br>
        <label>Estado:
            
                <select>
                       <option>Acre (AC)</option>
<option>Alagoas (AL)</option>
<option>Amapá (AP)</option>
<option>Amazonas (AM)</option>
<option>Bahia (BA)</option>
<option>Ceará (CE)</option>
<option>Distrito Federal (DF)</option>
<option>Espírito Santo (ES)</option>
<option>Goiás (GO)</option>
<option>Maranhão (MA)</option>
<option>Mato Grosso (MT)</option>
<option>Mato Grosso do Sul (MS)</option>
<option>Minas Gerais (MG)</option>
<option>Pará (PA) </option>
<option>Paraíba (PB)</option>
<option>Paraná (PR)</option>
<option>Pernambuco (PE)</option>
<option>Piauí (PI)</option>
<option>Rio de Janeiro (RJ)</option>
<option>Rio Grande do Norte (RN)</option>
<option>Rio Grande do Sul (RS)</option>
<option>Rondônia (RO)</option>
<option>Roraima (RR)</option>
<option>Santa Catarina (SC)</option>
<option>São Paulo (SP)</option>
<option>Sergipe (SE)</option>
<option>Tocantins (TO)</option>
    
                </select>
    </label>

    <br>
    <label>Cidade:
        
            <select>
                    <option>ES</option>
                    <option>ES</option>
                    <option>ES</option>

                    <option>ES</option>


            </select>
</label>

<br>
<label>RG :
    
<textarea name="RG:" id="RGText" cols="10" rows="01"></textarea>
</label>
<br>
<label>CNPJ/CPF:
    
<textarea name="CNPJ/CPF:" id="CNPJ/CPFtext" cols="10" rows="01"></textarea>
</label>
        <br>
        <br>
            <button id="Cadastro">Cadastro</button>
            <button id="Limpar">Cancelar</button>
    
        
            
                
                    
</from>
  </div>
<hr>

<div id="rodape">Desenvolvido:Grupo(Haroldo,Miqueias,Angelo,Kelly)</div>

<hr>

</body>
</html>